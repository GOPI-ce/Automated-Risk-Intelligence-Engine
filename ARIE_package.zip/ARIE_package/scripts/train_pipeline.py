# Simple train pipeline that ties everything together
from src.utils.helpers import generate_multimodal_dataset
from src.features.feature_store import build_features
from src.models.tabular_model import train_tabular
from src.models.nlp_model import embed_texts
from src.models.ts_model import compute_ts_score
from src.models.fusion import train_fusion
import numpy as np
import joblib
import os

os.makedirs('models', exist_ok=True)

def run():
    print('Generating data...')
    df = generate_multimodal_dataset(5000)
    print('Building features...')
    train, test = build_features()
    # select tabular columns
    tab_cols = ['price','quantity','amount','latency_ms','processing_delay']
    X_train = train[tab_cols].values
    y_train = train['label'].values
    X_test = test[tab_cols].values
    y_test = test['label'].values
    print('Training tabular model...')
    train_tabular(X_train, y_train, X_test, y_test)
    print('Embedding text...')
    text_emb = embed_texts(train['ticket_text'].tolist())
    text_emb_test = embed_texts(test['ticket_text'].tolist())
    print('Computing ts scores...')
    ts_scores = compute_ts_score(train)
    ts_scores_test = compute_ts_score(test)
    print('Training fusion model...')
    # simple alignment - trim if needed
    n = min(len(X_train), len(text_emb), len(ts_scores))
    clf = train_fusion(X_train[:n], text_emb[:n], ts_scores[:n], y_train[:n])
    print('Training complete. Models saved to models/')
if __name__ == '__main__':
    run()
