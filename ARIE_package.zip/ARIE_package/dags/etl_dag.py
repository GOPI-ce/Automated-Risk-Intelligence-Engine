from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta

def etl_task():
    from src.utils.helpers import generate_multimodal_dataset
    generate_multimodal_dataset(5000)

def train_task():
    from src.features.feature_store import build_features
    train, test = build_features()
    # train simple pipeline (omitted here; call scripts)
    print("Train done")

with DAG("arie_etl_train", start_date=datetime(2025,1,1), schedule_interval="@daily", catchup=False) as dag:
    etl = PythonOperator(task_id="etl", python_callable=etl_task)
    train = PythonOperator(task_id="train", python_callable=train_task)
    etl >> train
