import numpy as np
import pandas as pd
import random
from datetime import datetime, timedelta
from faker import Faker
fake = Faker()

def generate_multimodal_dataset(n=20000, start_date="2025-01-01"):
    """Generate synthetic multimodal rows: transaction (tabular), time-series metrics, and ticket text"""
    rows = []
    start = datetime.fromisoformat(start_date)
    products = ["OTC_Rates","OTC_FX","OTC_Credit","Exchange_Equity"]
    for i in range(n):
        txn_time = start + timedelta(minutes=random.randint(0, 60*24*180))
        product = random.choice(products)
        amount = round(np.random.exponential(100000), 2)
        counterparty = "CP_" + str(random.randint(1,200))
        trade_id = f"T{100000+i}"
        # produce small set of numeric features
        numeric = {
            "trade_id": trade_id,
            "timestamp": txn_time,
            "product": product,
            "amount": amount,
            "counterparty": counterparty,
            "price": round(np.random.normal(100, 10),2),
            "quantity": random.randint(1,1000)
        }
        # generate simple time-series metrics for the trade (avg latency etc.)
        metrics = {
            "latency_ms": max(0,int(np.random.normal(200,50))),
            "processing_delay": max(0,int(np.random.normal(5,3))),
            "num_retries": np.random.poisson(0.3)
        }
        # generate ticket text (sometimes indicating risk)
        risk_flag = np.random.rand() < 0.08  # 8% are risky
        if risk_flag:
            text = random.choice([
                f"Failure in trade matching for {trade_id}, counterparty {counterparty}. Missing LEI.",
                f"Settlement fails; collateral shortfall flagged for {counterparty}.",
                f"Unexpected notional discrepancy for trade {trade_id}, investigate pricing mis-match."
            ])
            label = 1
        else:
            text = random.choice([
                f"Routine query for trade {trade_id}.",
                f"Counterparty {counterparty} confirmation received.",
                f"Standard processing for {product} trade."
            ])
            label = 0
        row = {**numeric, **metrics, "ticket_text": text, "label": label}
        rows.append(row)
    df = pd.DataFrame(rows)
    # save
    # Ensure directory exists
    import os
    os.makedirs("data/processed", exist_ok=True)
    df.to_parquet("data/processed/multimodal_dataset.parquet", index=False)
    return df
