from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np
from src.models.nlp_model import embed_texts
from src.features.feature_store import build_features
from src.models.fusion import train_fusion

app = FastAPI(title="ARIE Inference API")

class PredictRequest(BaseModel):
    amount: float
    price: float
    quantity: int
    counterparty: str
    ticket_text: str
    latency_ms: float
    processing_delay: float

@app.post("/predict")
def predict(req: PredictRequest):
    # simple flow: transform -> embed -> concat -> predict
    tab = np.array([[req.price, req.quantity, req.amount, req.latency_ms, req.processing_delay]])
    text_emb = embed_texts([req.ticket_text])  # shape (1, dim)
    ts_score = np.array([[ (req.latency_ms - 0)/1 ]])  # placeholder
    # load fusion model
    model = joblib.load("models/fusion_model.joblib")
    X = np.hstack([tab, text_emb, ts_score])
    prob = model.predict_proba(X)[0,1]
    return {"risk_score": float(prob)}
