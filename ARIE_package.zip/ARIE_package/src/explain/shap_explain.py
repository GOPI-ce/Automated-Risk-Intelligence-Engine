import shap
import joblib
import numpy as np

def explain_model(fusion_model_path="models/fusion_model.joblib", sample_X=None):
    model = joblib.load(fusion_model_path)
    explainer = shap.LinearExplainer(model, sample_X, feature_dependence="independent")
    shap_vals = explainer.shap_values(sample_X)
    return shap_vals
