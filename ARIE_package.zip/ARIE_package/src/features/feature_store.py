import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

def build_features(path="data/processed/multimodal_dataset.parquet"):
    df = pd.read_parquet(path)
    # basic tabular features
    df['hour'] = df['timestamp'].dt.hour
    df['is_high_amount'] = (df['amount'] > df['amount'].quantile(0.9)).astype(int)
    # rolling counts per counterparty (requires sorted)
    df = df.sort_values('timestamp')
    df['cp_txn_24h'] = df.groupby('counterparty').cumcount()  # simple proxy
    # numeric scaling
    scaler = StandardScaler()
    df[['price','quantity','latency_ms','processing_delay']] = scaler.fit_transform(
        df[['price','quantity','latency_ms','processing_delay']])
    # split
    train, test = train_test_split(df, test_size=0.2, stratify=df['label'], random_state=42)
    return train, test
