import numpy as np
from sklearn.linear_model import LogisticRegression
import joblib
import os

def train_fusion(tabular_X, text_embeds, ts_scores, y, model_path="models/fusion_model.joblib"):
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    X = np.hstack([tabular_X, text_embeds, ts_scores.reshape(-1,1)])
    clf = LogisticRegression(max_iter=1000)
    clf.fit(X, y)
    joblib.dump(clf, model_path)
    return clf
