import numpy as np
def compute_ts_score(df):
    # simple z-score on latency over rolling window per counterparty
    df['latency_z'] = df.groupby('counterparty')['latency_ms'].transform(
        lambda x: (x - x.rolling(20, min_periods=1).mean()) / (x.rolling(20, min_periods=1).std().replace(0,1)))
    df['latency_z'].fillna(0, inplace=True)
    return df['latency_z'].values
