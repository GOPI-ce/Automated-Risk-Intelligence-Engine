from sentence_transformers import SentenceTransformer
import joblib

# Initialize model globally or inside function to avoid reloading overhead if possible, 
# but for this script structure, global is fine as per user snippet.
model = SentenceTransformer('all-MiniLM-L6-v2')

def embed_texts(texts):
    return model.encode(texts, show_progress_bar=True)
