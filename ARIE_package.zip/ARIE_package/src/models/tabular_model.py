import joblib
import xgboost as xgb
from sklearn.metrics import roc_auc_score
import os

def train_tabular(X_train, y_train, X_val, y_val, model_path="models/tabular_xgb.joblib"):
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    dtrain = xgb.DMatrix(X_train, label=y_train)
    dval = xgb.DMatrix(X_val, label=y_val)
    params = {"objective":"binary:logistic","eval_metric":"auc","eta":0.1, "max_depth":6}
    model = xgb.train(params, dtrain, num_boost_round=200, evals=[(dval,'val')], early_stopping_rounds=20)
    joblib.dump(model, model_path)
    preds = model.predict(dval)
    return model, roc_auc_score(y_val, preds)
