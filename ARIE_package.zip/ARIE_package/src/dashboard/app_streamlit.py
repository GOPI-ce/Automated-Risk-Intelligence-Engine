import streamlit as st
import requests
import pandas as pd
import plotly.graph_objects as go

# 1. Page Configuration
st.set_page_config(
    page_title="ARIE | Risk Intelligence",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 2. Custom CSS for Premium Dark Look
st.markdown("""
    <style>
    /* FORCE DARK MODE & TEXT COLOR */
    .stApp {
        background-color: #050505;
    }
    
    p, h1, h2, h3, h4, h5, h6, span, div, label {
        color: #e0e0e0 !important;
    }
    
    /* INPUT FIELDS - Remove White Backgrounds */
    .stTextInput input, .stNumberInput input, .stTextArea textarea {
        background-color: #1a1a1a !important;
        color: #00ffcc !important; /* Neon Cyan Text */
        border: 1px solid #333 !important;
    }
    
    /* Focus State for Inputs */
    .stTextInput input:focus, .stNumberInput input:focus, .stTextArea textarea:focus {
        border-color: #00ffcc !important;
        box-shadow: 0 0 10px rgba(0, 255, 204, 0.2) !important;
    }

    /* EXPANDER - Fix White Box */
    .streamlit-expanderHeader {
        background-color: #111 !important;
        color: #fff !important;
        border-radius: 5px;
    }
    div[data-testid="stExpander"] {
        background-color: #0a0a0a !important;
        border: 1px solid #333;
        border-radius: 5px;
    }
    div[data-testid="stExpander"] details {
        background-color: #0a0a0a !important;
    }
    
    /* BUTTONS */
    .stButton>button {
        background: linear-gradient(45deg, #00d2ff 0%, #3a7bd5 100%);
        color: white !important;
        border: none;
        font-weight: bold;
        letter-spacing: 1px;
        transition: all 0.3s ease;
    }
    .stButton>button:hover {
        transform: scale(1.02);
        box-shadow: 0 0 15px rgba(0, 210, 255, 0.5);
    }

    /* METRICS & HEADERS */
    h1 {
        background: -webkit-linear-gradient(0deg, #00d2ff, #928DAB);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    /* SLIDERS */
    div[data-baseweb="slider"] > div {
        background-color: transparent !important;
    }

    </style>
    """, unsafe_allow_html=True)

# 3. Header Section
col1, col2 = st.columns([3, 1])
with col1:
    st.title("ARIE")
    st.markdown("### 🛡️ Automated Risk Intelligence Engine")
    st.caption("Real-time multimodal trade surveillance system")

with col2:
    # Placeholder for a logo or status
    st.markdown("#### 🟢 System Online")

st.markdown("---")

# 4. Main Interface
with st.container():
    col_input, col_result = st.columns([1, 1], gap="large")

    with col_input:
        st.subheader("📝 Transaction Entry")
        
        # Using a container instead of expander if expander styling is stubborn, 
        # but with new CSS expander should look good.
        with st.expander("Transaction Details", expanded=True):
            c1, c2 = st.columns(2)
            with c1:
                amount = st.number_input("Amount ($)", min_value=0.0, value=10000.0, step=1000.0)
                price = st.number_input("Price ($)", min_value=0.0, value=100.0, step=1.0)
                quantity = st.number_input("Quantity", min_value=1, value=100, step=10)
            with c2:
                counterparty = st.text_input("Counterparty ID", value="CP_1")
                latency = st.slider("Network Latency (ms)", 0, 1000, 200)
                processing_delay = st.slider("Processing Delay (s)", 0, 60, 5)
            
            ticket = st.text_area("Log / Ticket Text", 
                                value="Settlement fails; collateral shortfall flagged.",
                                height=100)

        predict_btn = st.button("⚡ ANALYZE RISK", use_container_width=True)

    with col_result:
        st.subheader("📊 Intelligence Report")
        
        if predict_btn:
            with st.spinner("Processing Fusion Model..."):
                payload = {
                    "amount": amount,
                    "price": price,
                    "quantity": quantity,
                    "counterparty": counterparty,
                    "ticket_text": ticket,
                    "latency_ms": float(latency),
                    "processing_delay": float(processing_delay)
                }
                
                try:
                    r = requests.post("http://localhost:8000/predict", json=payload)
                    
                    if r.ok:
                        data = r.json()
                        risk_score = data.get("risk_score", 0)
                        
                        # Gauge Chart
                        fig = go.Figure(go.Indicator(
                            mode = "gauge+number",
                            value = risk_score * 100,
                            domain = {'x': [0, 1], 'y': [0, 1]},
                            title = {'text': "Risk Probability (%)", 'font': {'color': 'white', 'size': 20}},
                            number = {'font': {'color': 'white'}},
                            gauge = {
                                'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "white"},
                                'bar': {'color': "#ff0055" if risk_score > 0.5 else "#00ffaa"},
                                'bgcolor': "#1a1a1a",
                                'borderwidth': 2,
                                'bordercolor': "#333",
                                'steps': [
                                    {'range': [0, 30], 'color': 'rgba(0, 255, 170, 0.1)'},
                                    {'range': [30, 70], 'color': 'rgba(255, 255, 0, 0.1)'},
                                    {'range': [70, 100], 'color': 'rgba(255, 0, 85, 0.1)'}],
                                'threshold': {
                                    'line': {'color': "red", 'width': 4},
                                    'thickness': 0.75,
                                    'value': 85}}))
                        
                        fig.update_layout(
                            paper_bgcolor = "rgba(0,0,0,0)", 
                            font = {'color': "white", 'family': "Arial"},
                            margin=dict(l=20, r=20, t=50, b=20)
                        )
                        st.plotly_chart(fig, use_container_width=True)
                        
                        # Recommendation Card
                        if risk_score > 0.7:
                            st.markdown("""
                                <div style="background-color: rgba(255, 0, 85, 0.2); padding: 15px; border-radius: 10px; border: 1px solid #ff0055;">
                                    <h3 style="color: #ff0055; margin:0;">⛔ CRITICAL RISK</h3>
                                    <p style="margin:5px 0 0 0;">Immediate freeze recommended. High probability of settlement failure.</p>
                                </div>
                            """, unsafe_allow_html=True)
                        elif risk_score > 0.3:
                            st.markdown("""
                                <div style="background-color: rgba(255, 200, 0, 0.2); padding: 15px; border-radius: 10px; border: 1px solid #ffc800;">
                                    <h3 style="color: #ffc800; margin:0;">⚠️ MODERATE RISK</h3>
                                    <p style="margin:5px 0 0 0;">Manual review required. Check counterparty limits.</p>
                                </div>
                            """, unsafe_allow_html=True)
                        else:
                            st.markdown("""
                                <div style="background-color: rgba(0, 255, 170, 0.2); padding: 15px; border-radius: 10px; border: 1px solid #00ffaa;">
                                    <h3 style="color: #00ffaa; margin:0;">✅ LOW RISK</h3>
                                    <p style="margin:5px 0 0 0;">Transaction approved for auto-processing.</p>
                                </div>
                            """, unsafe_allow_html=True)
                            
                    else:
                        st.error(f"Server Error: {r.status_code}")
                        
                except Exception as e:
                    st.error("❌ API Connection Failed")
                    st.caption("Ensure the backend is running on port 8000")
        else:
            # Empty state
            st.markdown("""
            <div style="border: 1px dashed #333; border-radius: 10px; padding: 40px; text-align: center; color: #666;">
                <h3 style="color: #444;">Waiting for Analysis</h3>
                <p>Submit transaction details to generate risk report.</p>
            </div>
            """, unsafe_allow_html=True)

# 5. Footer
st.markdown("---")
st.caption("ARIE v1.0 | Enterprise Risk Management System")
