from src.utils.helpers import generate_multimodal_dataset

def run_etl():
    print("Running ETL Pipeline...")
    df = generate_multimodal_dataset(n=20000)
    print(f"Generated {len(df)} rows of data.")

if __name__ == "__main__":
    run_etl()
